//Theme Pizza 
//cheese pizza


function setup() {
  createCanvas(600, 600);
}
let value = 0;
function draw() {
  background('#0FABF2');
 
  var x = 0;
  while (x <= width) {
    ellipse(x, 500, 58, 20, 86, 75);
    x = x + 25;
  }

  
 
  
  text("Click anywhere to see pizza", 20, 20);
  text("Click any button on keyboard to change color of pizza", 20, 30)
  
  fill(0);
  fill('#FB5612')
   if (mouseIsPressed === true) {
    triangle(300, 300, 58, 200, 196, 75);
     //triangle(x1, y1, x2, y2, x3, y3)
  } else {
    ellipse(300, 300, 530, 490);
  }

  print(mouseIsPressed);
  
  
   fill(value);
  //fill('#F26638');
  triangle(300, 300, 58, 200, 196, 75);
  triangle(300, 300, 55, 210, 40, 340);
  triangle(300, 300, 210, 72, 350, 60);
  triangle(300, 300, 370, 64, 510, 150);
  triangle(300, 300, 565, 280, 520, 170);
  triangle(300, 300, 565, 300, 530, 420);
  triangle(300, 300, 380, 534, 523, 430);
  triangle(300, 300, 160, 509, 370, 535);
  triangle(300,300, 155, 507, 40, 350);
  //triangle(x1, y1, x2, y2, x3, y3)
}

function mousePressed() {
  if (value === 0) {
    value = '#F26638';
  } else {
    value = 0;
    
    
  }
}
function keyPressed() {
  if (value === 0) {
    value = '#E87B35';
  } else {
    value = 0;
  } 
}  




