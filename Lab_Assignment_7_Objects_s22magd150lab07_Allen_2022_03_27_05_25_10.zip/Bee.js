class Bee{
  constructor() {
    this.x = 200;
    this.y = 150;
    
  }
  
  move() {
    this.x = this.x + random(-5,5);
    this.y = this.y + random(-5,5);
    
  }
  
  show() {
    stroke('yellow');
    strokeWeight(4);
    fill('yellow');
    ellipse(this.x, this.y, 50, 30); //body of bee
    fill('black');
    strokeWeight(1)
    ellipse(this.x + -10, this.y + -30, 20, 30); //bee wing
    ellipse(this.x + -2, this.y + -30, 20, 30); //bee wing 
    ellipse(this.x + 13, this.y + -8, 10, 10); // bee eye
    line(this.x, this.y, 50, 130, 60)
    // make a line that goes too a flower
    
  }
  
}