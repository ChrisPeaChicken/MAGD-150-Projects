let ballX = 0;
let soundFile;
let sound, amplitude;
//let gif;
// work still need to be done 
function preload() {
  
  //soundFormats('ogg', 'mp3');
  song = loadSound('bensound-tomorrow.mp3');
  sound = loadSound("bensound-dubstep.mp3");
  
}


function setup() {
  let cnv = createCanvas(400, 400);
  cnv.mouseClicked(togglePlay);
  amplitude = new p5.Amplitude();
  
  
  createCanvas(400, 400);
  
  song.loop();
}

function draw() {
  background(220);
 
 
  
  
  fill('black');
  text('tap to play/stop', 10, 20);
  let level = amplitude.getLevel();
  let size = map(level, 0,1,0,200);
  fill('yellow');
  ellipse(width/2, height/2, size, size)
  
  //let cnv = createCanvas(400, 400);
  //cnv.mousePressed(canvasPressed);
  ballX = constrain(mouseX, 0, width);
  fill('blue');
  ellipse(ballX, height/2, 20, 20);
  
  fill('black');
  var circleSize = map(level,0, 20, 60, 400); // makes the mirror move
  rect(100, 0, 200, 400, circleSize,circleSize); //outline of the mirror 
  fill('white');
  rect(125, 20, 150, 360, circleSize,circleSize); // clear part of the mirror
}

function canvasPressed(){
  // map the ball's x location to a panning degree
  // between -1.0 (left) and 1.0 (right)
  
  let panning = map(ballX, 0.0, width,-1.0, 1.0);
  soundFile.pan(panning);
  soundFile.play();
}

function togglePlay() {
  if (sound.isPlaying() ){
    sound.pause();
  } else {
    sound.loop();
    
    amplitude = new p5.Amplitude();
    amplitude.setInput(sound);
  }
}

