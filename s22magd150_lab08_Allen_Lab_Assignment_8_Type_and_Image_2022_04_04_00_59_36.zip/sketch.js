let img;
let Ryan2;
let DeadPool;
let Sams;
let fontBold;
let result;

let x;
let y;

let font,
    fontsize = 40;

function preload() {
  img = loadImage('Chip/purpChip.png');
  Ryan2 = loadImage('Chip/Ryan2.jpg');
  DeadPool = loadImage('Chip/DeadPool.jpg');
  Sams = loadImage('Chip/Sams.jpeg');
  result = loadStrings('Chip/cooltxt.txt');
  BlueRyan2 = loadImage('Chip/BlueRyan2.jpg');// ryan2 cut in half
}

function setup() {
  createCanvas(400, 500);


  //DeadPool.blend(Ryan2, 0, 0, 33, 100, 67, 0, 33, 100, LIGHTEST);
  image(DeadPool,0, 0, 0);

  textSize(fontsize);
  textAlign(CENTER, CENTER);
  
  Ryan2.filter(GRAY);
  //image(Ryan2, 10, 0, 10, 10);
  //image(Ryan2, width / 2,0);


}



function drawWords(x) {
  fill('black'); // make bit darker red
  text('Average', x, 30, 300); // try to make the text go infront of objects 
  text('Joe', x, 65, 300);
  text('I', -10, 100, width);
}

function draw() {
  //background('#0B5ED4');
  noTint();
  textAlign(RIGHT);//text 
  drawWords(width * 0.25); 
  //image is poker chip
  image(img, 25, 240, 70, 70);
  //Ryan2 is ryanreynold 
  image(Ryan2, 0, 0, 120, 120); 
  
  fill('#DF07FA')
  ellipse(200, 490, 400, 300); // purple sun
  fill('#F5661D');
  triangle(10, 420, -50, 300, 46, 380); //ray or sun 1 all way to left read from left to right
 // x1 and y1 bottom left x2 and y2 top x3 and y bottom right
  
  triangle(50, 375, 0, 285, 96, 350); 
  triangle(105, 345, 100, 240, 160, 330);
  triangle(174, 330, 190, 230, 240, 330);
  triangle(250, 332, 285, 230, 300, 350);
  triangle(310, 353, 370, 255, 350, 375); 
  triangle(360, 378, 490, 230, 400, 420);
  fill('#F545C9');
  tint("#26F0D4");
  image(Sams, 100, 350, 200, 200);
  text(result, 100, 390, 170)
  noTint();
  image(BlueRyan2, 0, 0, 64, 120); // makes black and blue ryan renolds look half and half 
  




}


