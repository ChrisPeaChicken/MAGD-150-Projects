let angle = 0;
let Chicago;
let Loui;
let Bridge;
let map;
let train2;

let gif1;
let gif2;
let gif3;
let gif4;
let gif5;
let gif6;

var train;


function preload() {
  
 train = loadJSON('train.json'); 
  
Chicago = loadImage('photo/Chicago.jpg');
Loui = loadImage('photo/Loui.jpg');
Bridge = loadImage('photo/Bridge.jpg');
train2 = loadImage('photo/train2.jpg');
  
gif1 = loadImage('cars/car1.gif');
gif2 = loadImage('cars/car2.gif');
gif3 = loadImage('cars/car3.gif');
gif4 = loadImage('cars/car4.gif');
gif5 = loadImage('cars/car5.gif');
gif6 = loadImage('cars/car6.gif');

}

function setup() {
  createCanvas(800, 400, WEBGL);


  
}

function draw() {
  background(172);

    fill(train.r, train.g, train.b);
  text(train.name, 10, 50); 
  
  image(train2, -450, -80, 200, 200); // map of train station route
   
  rotateY(angle);
  translate(-400, -150);
  texture(gif1);
  box(50,50,50) // moving cars
  
  translate(-200, -150);
  texture(gif2); // more moving
  box(60, 60, 60);
  
  
  camera(100, 100, 320 + sin(frameCount * 0.01) * 10, 10, 10, 0, 0, 10, 10); // changes the angle i look at objects
 
  
  rectMode(CENTER);
  
  let dx = mouseX - width / 2;
  let dy = mouseY - height / 2;
  
  
  ambientMaterial(255);
  directionalLight('black', 255, dx, dy); //, 0); 
  rotateZ(angle);
  translate(100, 25)
  ambientLight(60);
  pointLight(255, 255, 255, dx, dy, 50);
  specularMaterial(250);
  shininess(50);
  translate(-100, -20);
  torus(150, 20, 100, 100); // outside ring or big ring
  
  
  rotate(angle);
  translate(10, 100);
  texture(Bridge); // cool loking bridge
 // texture(gif1); // moving cars gif1
  box(40, 10, 80, 80); // the rectangle that rotates around sphere
  translate(-10, -100);
  
  
  noStroke();
  rotateZ(angle * 0.7);
  rotateY(angle * 0.4);
  rotateX(angle * 1.0);
  // x,z,y
  texture(Chicago);
  box(60, 60, 60); // chicago in middle
  
  
  angle += 0.01;
  
  

}
