let bee1;
let bee2;
let bee3;
let bee4;
let bee5;
let bee6;

var nums = [40, 60, 5, 110]; 

function setup() {
  createCanvas(600, 400);
  
  bee1 = new Bee();
  bee2 = new Bee();
  bee3 = new Bee();
  bee4 = new Bee();
  bee5 = new Bee();
  bee6 = new Bee();
  
}

function draw() {
 background('#0081FA');
  

  
  // flower head 
  noStroke();
  fill('#FABA00');
  ellipse(50, 130, 55, 55);
  fill('black');
  ellipse(33, 120, nums[2], nums[2]); // flower dots
  ellipse(45, 115, nums[2], nums[2]); // flower dots
  ellipse(60, 112, nums[2], nums[2]); // flower dots
  ellipse(40, 130, nums[2], nums[2]); // flower dots
  ellipse(50, 117, nums[2], nums[2]); // flower dots
  ellipse(70, 140, nums[2], nums[2]); // flower dots
  ellipse(60, 137, nums[2], nums[2]); // flower dots
  ellipse(65, 120, nums[2], nums[2]); // flower dots
  ellipse(55, 128, nums[2], nums[2]); // flower dots
  ellipse(73, 127, nums[2], nums[2]); // flower dots
  ellipse(30, 140, nums[2], nums[2]); // flower dots
  ellipse(32, 130, nums[2], nums[2]); // flower dots
  ellipse(43, 140, nums[2], nums[2]); // flower dots
  ellipse(48, 143, nums[2], nums[2]); // flower dots
  ellipse(54, 147, nums[2], nums[2]); // flower dots
  
    // stem of flower
  noStroke();
  fill('#206B00')
  rect(30, 200, 45, 200);
  rect(60, 250, 55, 55, 20, 15, 10, 60);
  rect(-10, 230, 55, 55, 20, 15, 10, 5);
  
  //flower pedal
  fill('#E3C800');
  ellipse(56, 74, nums[0], nums[1]);
  ellipse(34, 79, nums[0], nums[1]);
  //stroke(5);
  ellipse(1, nums[3], nums[1], nums[0]);
  ellipse(-5, 140, nums[1], nums[0]);
  ellipse(30, 180, nums[0], nums[1]);
  ellipse(60, 183, nums[0], nums[1]);
  ellipse(100, nums[3], nums[1], nums[0]);
  ellipse(104, 140, nums[1], nums[0]);
  
  bee1.move();
  bee1.show();
  bee2.move();
  bee2.show();
  bee3.move();
  bee3.show();
  bee4.move();
  bee4.show();
  bee5.move();
  bee5.show();
  bee6.move();
  bee6.show();
}